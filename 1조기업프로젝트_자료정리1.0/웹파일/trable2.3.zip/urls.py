from django.urls import path




from . import views

urlpatterns = [
    ### http://127.0.0.1:8000/main/main
    path('', views.main),
    path('login/', views.login),
    path('signup/', views.signup),
    path('side/', views.side),
    path('mi/', views.MI),
    #지방 페이지
    path('seoul/', views.province_seoul),
    #상세 정보 페이지
    path('ttuk/', views.ttuk),
    path('ship/', views.ship),
    path('seoulcul/', views.cul),
    #마커 테스트
    path('maker/', views.maker),
]