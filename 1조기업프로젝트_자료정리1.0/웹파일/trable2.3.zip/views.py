from django.shortcuts import render
from django.http import HttpResponse
from django.core.paginator import Paginator
import random

# Create your views here.

# 메인페이지
def main(request) :
    return render(request,
                  "trableapp/main.html")


### 로그인페이지
def login(request) :
    return render(request,
                  "trableapp/login.html")

### 회원가입페이지 
def signup(request) :
    return render(request,
                  "trableapp/signup.html")

### 전국페이지 
def side(request) :
    return render(request,
                  "trableapp/side.html")

# 지방 화면
from django.shortcuts import render
import random

def province_seoul(request):
    tourist_areas = [
        {
            'name': '경복궁',
            'image': 'trable/img/seoul_tour/경복궁.jpg',
            'location': '서울시 종로구',
        },
        {
            'name': 'N 타워',
            'image': 'trable/img/seoul_tour/N타워.jpg',
            'location': '서울시 용산구',
        },
        {
            'name': '북촌한옥마을',
            'image': 'trable/img/seoul_tour/북촌한옥마을.jpg',
            'location': '서울시 종로구',
        },
        {
            'name': '베베베',
            'image': 'https://a.cdn-hotels.com/gdcs/production146/d7/1272dc18-817c-436d-b9ac-47e0a139e998.jpg',
            'location': '서울시 송파구',
        },
        {
            'name': '롯데월드',
            'image': 'trable/img/lotte_world.png',
            'location': '서울시 송파구',
        },
        {
            'name': '롯데월드',
            'image': 'trable/img/lotte_world.png',
            'location': '서울시 송파구',
        },
        {
            'name': '롯데월드',
            'image': 'trable/img/lotte_world.png',
            'location': '서울시 송파구',
        },
        {
            'name': '롯데월드',
            'image': 'trable/img/lotte_world.png',
            'location': '서울시 송파구',
        },
        {
            'name': '롯데월드',
            'image': 'trable/img/lotte_world.png',
            'location': '서울시 송파구',
        },
        # 추가적인 여행지 정보...
    ]

    food_areas = [
        {
            'name': '광양숯불구이',
            'image': 'trable/img/Gwangju_Restaurant/a.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '금수저은수저',
            'image': 'trable/img/Gwangju_Restaurant/b.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '남쪽마을돌짜장',
            'image': 'trable/img/Gwangju_Restaurant/남쪽마을돌짜장.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '농성화로',
            'image': 'trable/img/Gwangju_Restaurant/농성화로.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '동명더밥',
            'image': 'trable/img/Gwangju_Restaurant/동명더밥.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '보향미',
            'image': 'trable/img/Gwangju_Restaurant/보향미.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '비바로마',
            'image': 'trable/img/Gwangju_Restaurant/비바로마.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '아얏리돌솥밥',
            'image': 'trable/img/Gwangju_Restaurant/오얏리돌솥밥.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '제주흑돈하루노',
            'image': 'trable/img/Gwangju_Restaurant/제주흑돈하루노대점.jpg',
            'location': '광주 지산점',
        },
        {
            'name': '프랭크커핀',
            'image': 'trable/img/Gwangju_Restaurant/프랭크커핀바광주동명점.jpg',
            'location': '광주 지산점',
        },

        # 추가적인 음식점 정보...
    ]
    
    random.shuffle(tourist_areas)  # tourist_areas 리스트를 랜덤하게 섞음
    selected_tourist_areas = tourist_areas[:5]  # 섞인 리스트 중에서 처음 5개 항목 선택

    random.shuffle(food_areas)  # food_areas 리스트를 랜덤하게 섞음
    selected_food_areas = food_areas[:5]  # 섞인 리스트 중에서 처음 5개 항목 선택

    context = {
        'tourist_areas': selected_tourist_areas,
        'food_areas': selected_food_areas,
    }

    return render(request, 'trableapp/province_seoul.html', context)



#상세 페이지
def MI(request) :
    return render(request,
                  "trableapp/more_information.html")

#상세 떡축제 페이지
def ttuk(request) :
    return render(request,
                  "trableapp/festival/ttuk.html")

#상세 뱃놀이 페이지
def ship(request) :
    return render(request,
                  "trableapp/festival/shipplay.html")


#상세 서울 문화 페이지
def cul(request) :
    return render(request,
                  "trableapp/festival/seoulcul.html")






#마커테스트
def maker(request) :
    return render(request,
                  "trableapp/maker.html")




